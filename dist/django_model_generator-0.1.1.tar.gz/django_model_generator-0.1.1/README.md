# Django Model Generator

A Django app for generating boilerplate code for models, admin interfaces, and APIs.

## Installation

```bash
pip install django-model-generator